<?php
    include(dirname(__FILE__).'/core/runtime/runtime.php');
?>