d3 = {version: "2.9.6"}; // semver
