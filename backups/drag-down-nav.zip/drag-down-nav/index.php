<!DOCTYPE html>
<html>
	<head>
	<title>Twitter/Flickr Feed</title>
	<meta charset="UTF-8" />
	<meta name="description" content="" />
	<link href="img/favicon.ico" rel="shortcut icon" />
	<link rel="stylesheet" href="css/style.css" type="text/css"/>
</head>
<body>
	<div class="container">
		<div class="nav-main">
			<nav>
				<ul>
				  <li>Nav item</li>
				  <li>Nav item</li>
				  <li>Nav item</li>
				  <li>Nav item</li>
				</ul>
			</nav>
			<a href="#" id="handle">Pull down</a>
		</div>

	</div>

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="js/app.js"></script>
	<!--http://idgettr.com/-->
</body>
</html>