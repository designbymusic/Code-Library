$(function(){
	//$('#container').tweetable({username: 'designbymusic', time: true, limit: 25, replies: true, position: 'append'});
 	
});

$(window).load(function(){
	//$('#container').isotope({ itemSelector : '.box', sortBy : 'random' });
});

$(window).load(function() {
	$("#background").fullBg();
});
getFeeds();

function buildGrid(objects){
	var html='';
	for(var i in objects){
		html += '<div class="box">';
		if(objects[i].thumbnail){
			html += '<img src="'+objects[i].thumbnail+'" />';
		}else{
			console.log(objects[i].content)
			html += objects[i].content;
		}
		
		html += '</div>';
	}	
	$('#container').append(html)
}

function getFeeds(){
	var defaults={
		flickr_id: '88768569@N03'
	};
	
	var processedFlickrFeed;
	var processedTwitterFeed;
	var mergedObjects = [];

	$.when(
		$.ajax({
			async: false,
			dataType: 'jsonp',  	
			url:'http://api.flickr.com/services/feeds/photos_public.gne?format=json&id='+defaults.flickr_id+'&jsoncallback=?'
		}),
		$.ajax({
			async: false,
			dataType: 'jsonp',  	
			url:'http://api.twitter.com/1/statuses/user_timeline.json?screen_name=_iamdash'
		})
	).then(function (flickrObj, twitterObj) {
		var flickrObject = flickrObj[0].items;

		$.each(flickrObject, function(i,item){
			console.log(item)
			mergedObjects.push({
				'type'		: 	'flickr', 
				'time' 		: 	new Date(item.date_taken).getTime(),
				'thumbnail' : 	item.media.m,
				'content'	: 	item.description
			});
		});
		
		var twitterObject = twitterObj[0];

		$.each(twitterObject, function(i,item){
			mergedObjects.push({
				'type'		: 	'twitter', 
				'time' 		: 	new Date(item.created_at).getTime(),
				//'thumbnail' : 	item.media.m,
				'content'	: 	item.text
			});
		});		
		mergedObjects.sort(compare);
		
		buildGrid(mergedObjects);

	});

}
function compare(a,b) {
  if (a.time > b.time)
     return -1;
  if (a.time < b.time)
    return 1;
  return 0;
}

	