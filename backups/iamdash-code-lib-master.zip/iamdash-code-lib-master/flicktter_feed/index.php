<!DOCTYPE html>
<html>
	<head>
	<title>Twitter/Flickr Feed</title>
	<meta charset="UTF-8" />
	<meta name="description" content="" />
	<link href="img/favicon.ico" rel="shortcut icon" />
	<link rel="stylesheet" href="style.css" type="text/css"/>
</head>
<body>
	<div id="container">

	</div>

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<?php /*<script src="js/jquery.tweetable.js"></script>
	<script src="js/jquery.flickrush.js"></script>
	<script src="js/jquery.isotope.js"></script>*/?>
	<script src="js/json2.js"></script>
	<script src="js/app.js"></script>
	<!--http://idgettr.com/-->
</body>
</html>