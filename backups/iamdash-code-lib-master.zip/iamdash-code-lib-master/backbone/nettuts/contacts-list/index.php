<?php
DEFINE('SHOW_ERRORS', 1);
error_reporting(3);
ini_set(display_errors, SHOW_ERRORS);

$db_host = "localhost";
$db_name = "iamdashdev_localhost";
$db_user = "root";
$db_pass = "armada";

// DB Connection
function db($action) {
     global $db_host, $db_user, $db_pass, $db_name;
     if ($action == "on") {
          if (!mysql_connect($db_host, $db_user, $db_pass)) {
               print mysql_error();
          }
          if (!mysql_select_db($db_name)) {
               print mysql_error();
          }
     } elseif ($action == "off")
          mysql_close();
}

function getContactData(){
    db('on');
    $s = 'SELECT * FROM backbone_contacts';
    $q = mysql_query($s);
    //$rows = mysql_fetch_array($q);
    while($row = mysql_fetch_assoc($q)){
        //unset($row['id']);
        $rows[] = $row;
        
    }
    return json_encode($rows);
    db('off');
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Backbone.js Web App</title>
        <link rel="stylesheet" href="css/screen.css" />
    </head>
    <body>
        <div id="contacts">
            <header>
                <div id="filter"><label>Show me:</label></div>
                <a id="showForm" href="#">Add new contact</a>
                <form id="addContact" action="#">
                    <label for="photo">photo:</label><input id="photo" type="file" />
                    <label for="type">Type:</label><input id="type" />
                    <label for="name">Name:</label><input id="name" />
                    <label for="address">Address:</label><input id="address" />
                    <label for="tel">Tel:</label><input id="tel" />
                    <label for="email">Email:</label><input id="email" />
                    <button id="add">Add</button>
                </form>                        
            </header>
        </div>
        <script id="contactTemplate" type="text/template">
            <img src="<%= photo %>" alt="<%= name %>" />
            <h1><%= name %><span><%= type %></span></h1>
            <div><%= address %></div>
            <dl>
                <dt>Tel:</dt><dd><%= tel %></dd>
                <dt>Email:</dt><dd><a href="mailto:<%= email %>"><%= email %></a></dd>
            </dl>
            <input type="hidden" class="id" value="<%= id %>" />
            <button class="edit">Edit</button>
            <button class="delete">Delete</button>
        </script>
        <script id="contactEditTemplate" type="text/template">
            <form action="#">
                <input type="file" value="<%= photo %>" />
                <input class="name" value="<%= name %>" />
                <input id="type" type="hidden" value="<%= type %>" />
                <input class="address" value="<%= address %>" />
                <input class="tel" value="<%= tel %>" />
                <input class="email" value="<%= email %>" />
                <button class="save">Save</button>
                <button class="cancel">Cancel</button>
            </form>
        </script>        
        <script src="js/jquery-1.7.1.min.js"></script>
        <script src="js/Underscore-min.js"></script>
        <script src="js/Backbone-min.js"></script>
        
        <script>
            var contacts = <?php echo getContactData() ?>;
            console.log(contacts)
        </script>        
        
        
        <script src="js/app.js"></script>
    </body>
</html>