<?php
session_start();

require_once 'class.hangman.php';

$game = new Hangman();

if(isset($_GET['action'])){
    switch ($_GET['action']){
        case 'restart':
            $game->restart();
        break;
    }
    header('Location: '.$_SERVER['PHP_SELF']);
}

if(isset($_POST['submit'])){
    $game->checkSubmittedLetters($_POST['letter']);
}
$cur_game = $game->getCurrentGame();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

	<title>Hangman</title>
        <style type="text/css">
            
            body{
                font-size: 120%;
            }
            
            input{
                font-size: 24px;
                padding: 10px;
                text-align: center;
                width: 70px;
            }
            input[type=submit]{
                display: block;
                height: 40px;
                line-height: 40px;
                width: 100px;
            }
            input[readonly=readonly]{
                border: none;
            } 
            #error_progress{
                background: #eee;
                border: 1px solid #999;
                height: 30px;
                overflow: hidden;
                position: relative;
                width: 500px;
            }
            #error_progress span{
                background: red;
                height: 30px;
                left: 0;
                position: absolute;
                top: 0;
                width: 0;
            }
            .error{
                color: red;
            }
            .success{
                color: green;
            }
        </style>
</head>

<body>
    <p><a href="<?php $_SERVER['PHP_SELF'];?>?action=restart">Click here to start the game</a></p>
    

    <?php if(isset($_SESSION['game']['game_complete'])):?>
        <h1>Game complete!</h1>
    <?php else:?>
        <?php if(!empty($_SESSION['game']['game_over'])):?>
            <h1>Game over!</h1>
            <h2>The word was <em><?php echo $_SESSION['game']['current_word'];?></em></h2>
        <?php $game->endGame();?>
        <?php else:?>
                <?php if(isset($_SESSION['game']['message'])):?>
                    <h3 class="<?php echo $_SESSION['game']['message']['class'];?>"><?php echo $_SESSION['game']['message']['copy'];?></h3>
                    <?php unset($_SESSION['game']['message']);?>
                <?php endif;?>            
            <h3>Clue: <?php echo $_SESSION['game']['current_clue'];?></h3>
            <form action="<?php $_SERVER['PHP_SELF'];?>" method="post">
                <?php for($i=0; $i<strlen($_SESSION['game']['current_word']); $i++):?>
                <input type="text" value="<?php echo !empty($_SESSION['game']['correct_letters'][$i]) ? $_SESSION['game']['correct_letters'][$i]:'' ;?>" maxlength="1" name="letter[]" <?php echo !empty($cur_game['correct_letters'][$i]) ? 'readonly="readonly"':'' ;?>" />
                <?php endfor;?>
                <input type="submit" name="submit" value="Submit" />
            </form>
        <div id="error_progress">
            <span style="width:<?php echo intval(100*$_SESSION['game']['wrong_guesses']);?>px"></span>
        </div>
        <?php endif;?>
    <?php endif;?>
</body>
</html>
