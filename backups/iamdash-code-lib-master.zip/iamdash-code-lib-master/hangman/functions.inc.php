<?php
ini_set('error_reporting', E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
DEFINE('SHOW_ERRORS', 1);

/**
 * 	Print any array in a readable format
 * 	@param	array	 Array to format
 * 	@return string
 */
function debug($array) {
    if (SHOW_ERRORS > 0) {
        echo '<pre style="padding: 20px; background: #fc0;color: #000; margin: 10px;padding: 10px">' . print_r($array, true) . '</pre>';
    }
}
?>
