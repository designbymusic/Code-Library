<?php

require_once 'functions.inc.php';

/*
 * class Hangman
 */

class Hangman{
    
    var $words = array(
        0=>array(
            'word'=>'antidisestablishmentarianism',
            'clue'=>'Opposition to the disestablishment of the Church of England'
        ),
        1=>array(
            'word'=>'bikes',
            'clue'=>'More than one of a two-wheeled pedal-powered type of machine'
        ),
        2=>array(
            'word'=>'cheeseburgers',
            'clue'=>'One variation is called a "Royale-with-Cheese" in France. Apparently.'
        ),
        3=>array(
            'word'=>'crackerjack',
            'clue'=>'Popcorn snack. Also the name of a disconinued UK children\'s television programme.'
        ),
        4=>array(
            'word'=>'fusion',
            'clue'=>'The process by which two or more atomic nuclei join together'
        ),
        5=>array(
            'word'=>'mammalian',
            'clue'=>'Used to describe warm-blooded vertebrate animals. Adjective.'
        )
    );
    var $num_allowed_errors = 5;
    var $current_game       = array();
    
    public function __construct() {
        $this->getWord();
    }
    
    /**
     *  @name   getWord
     *  @desc   Get a random word from the words array
     *  @todo   Check session for previoulsy completed words and exclude these when returning a word to use in the game
     *  @return string 
     */
    public function getWord(){
        
        $random_key = rand(0, count($this->words));
        $word = $this->words[$random_key];
        $_SESSION['game']['num_allowed_errors'] = $this->num_allowed_errors;
        $_SESSION['game']['num_user_errors'] = 0;

        if(empty($_SESSION['game']['current_word'])){
            $_SESSION['game']['current_word'] = $word['word'];
            $_SESSION['game']['current_clue'] = $word['clue'];
            $_SESSION['game']['letters']      = str_split($_SESSION['game']['current_word']);
        }
  
        
        $_SESSION['game'] = $_SESSION['game'];

        return $_SESSION['game']['current_word'];
    }
    
    public function getCurrentGame(){
        return $_SESSION['game'];
    }
    
    /*
     * @name    checkSubmittedLetters
     * @desc    Checks to see if the submitted letter matched up to the same key in the word
     * @param   array   The submitted letters
     * @return  void 
     */
    public function checkSubmittedLetters($letters){
        
        $i=0;
        $wrong_guesses = $_SESSION['game']['num_user_errors'];

        foreach($letters as $key=>$l){
            
            if($_SESSION['game']['letters'][$key] == $l){
                $_SESSION['game']['correct_letters'][$key] = $l;
                $_SESSION['game']['message']['copy'] = 'Well done!';
                $_SESSION['game']['message']['class'] = 'success';
            }elseif(!empty($letters[$key])){
                $_SESSION['game']['message']['copy'] = 'Sorry, wrong!';
                $_SESSION['game']['message']['class'] = 'error';                
                $wrong_guesses +=1;
            }
            
            $i++;
        }
        
        $_SESSION['game']['num_user_errors'] = $wrong_guesses;
        $_SESSION['game']['wrong_guesses']  +=  $wrong_guesses;
        
        if($_SESSION['game']['correct_letters']){
            ksort($_SESSION['game']['correct_letters']);
        }
        if($_SESSION['game']['wrong_guesses']>=$this->num_allowed_errors){
            $_SESSION['game']['game_over'] = 1;
        }elseif(implode($letters) == $_SESSION['game']['current_word']){
            $_SESSION['game']['game_complete'] = 1;
        }

        $_SESSION['game'] = $_SESSION['game'];
    }
    
    /**
     *  @name   restart
     *  @desc   Ends a game by calling $this::endGame
     *  @return  void 
     */
    public function restart(){
        $this->endGame();
    }    
    
    /**
     *  @name   endGame
     *  @desc   Ends a game by deleting session data
     *  @return  void 
     */
    public function endGame(){
        unset($_SESSION['game']);
    }
    
}



?>
