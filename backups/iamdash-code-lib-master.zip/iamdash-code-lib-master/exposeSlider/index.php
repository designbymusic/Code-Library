<!DOCTYPE html>
<html>
    <head>
        <title>Expose Slider</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="css/styles.css" type="text/css"/>
    </head>
    <body>
        <a href="content.html">launch content</a>
        <script src="js/jquery.js"></script>
        <script src="js/jquery.cycle.all.js"></script>
        <script src="js/jquery.exposeSlider.js"></script>
        <script>
            $(window).load(function(){
                $('a').exposeSlider();
            });    
        </script>
    </body>
</html>
