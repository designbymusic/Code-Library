/*!
 * jQuery lightweight plugin boilerplate
 * Original author: @ajpiano
 * Further changes, comments: @addyosmani
 * Licensed under the MIT license
 */


// the semi-colon before the function invocation is a safety 
// net against concatenated scripts and/or other plugins 
// that are not closed properly.
;(function ( $, window, document, undefined ) {
    
    // undefined is used here as the undefined global 
    // variable in ECMAScript 3 and is mutable (i.e. it can 
    // be changed by someone else). undefined isn't really 
    // being passed in so we can ensure that its value is 
    // truly undefined. In ES5, undefined can no longer be 
    // modified.
    
    // window and document are passed through as local 
    // variables rather than as globals, because this (slightly) 
    // quickens the resolution process and can be more 
    // efficiently minified (especially when both are 
    // regularly referenced in your plugin).

    // Create the defaults once
    var pluginName = 'exposeSlider',
    	$self,
        document = window.document,
        overlay,
        overlay_loaded = false,
        defaults = {
            fadeSpeed: 500,
            closeButton: '#overlay span.close',
            mediaTypes: 'img, video',
            slideElements: '#overlay section'
        };
        

    // The actual plugin constructor
    function Plugin( element, options ) {
        this.element = element;

        this.options = $.extend( {}, defaults, options) ;
        
        this._defaults = defaults;
        this._name = pluginName;
        
        this.init();
        _self = this;
    }

    // Initialise
    Plugin.prototype.init = function () {
        // Perform the click action to start building the overlay
        $(this.element).bind('click', function(e){
        	e.preventDefault();
        	_self.openOverlay();
        });
        this.resizeWindowDims();
    };

    // Open the overlay
    Plugin.prototype.openOverlay = function () {
    	_self.buildOverlay(function(){
              $('#overlay').fadeIn(_self._defaults.fadeSpeed, function(){
                    $(this).find('article').cycle({
                        containerResize: true,
                        slideResize: true,
                        fit: 1
                    }
                    );
              });
            }
        );
    };

    // Construct the overlay and append to the body
    Plugin.prototype.buildOverlay = function (callback) {
    	overlay = $('<div id="overlay"><span class="close">X</span></div>');
    	if($('#overlay').length == 0){
    		
            if(typeof callback === 'function'){
                _self.getContent(function(data){
                    overlay.html(data);
                    overlay.appendTo('body');
                    _self.resizeMedia();
                    _self.initClose();
                    callback.call(overlay);
                });
            }
    	}
    };

    // Perform the ajax call to get the content
    // this will be to a page that contains the slide elements
    // as defined in _self._defaults.slideElements
    Plugin.prototype.getContent = function (callback) {
        $.ajax({
            url: $(_self.element).attr('href'),
            context: $(this),
            success: function(data){
                overlay_loaded = true;
                callback(data);
            }
        });
    };

    // Initialise the controls to close the overlay
    // The 'controls' are either the close button or the escape key
    Plugin.prototype.initClose = function () {
        $(_self._defaults.closeButton).bind('click', function(){
            _self.closeOverlay();
        });
        $(document).keyup(function(e) {
            var code = (e.keyCode ? e.keyCode : e.which);
            if(code == 27) {
                _self.closeOverlay();
            }
        });
    };

    // Close the overlay and remove from the DOM
    Plugin.prototype.closeOverlay = function () {
        if($(overlay).length > 0){
            overlay.fadeOut(_self._defaults.fadeSpeed/2, function(){
                $(overlay).remove();
            });
        }
    };

    // Update the width and height of the slides within the overlay
    Plugin.prototype.resizeMedia = function () {
        var $win_w = $(window).width();
        var $win_h = $(window).height();
        if(overlay_loaded){
            $(_self._defaults.slideElements).each(function(){

                $(this).css({
                    'height':$win_h,
                    'width':$win_w
                });

                var media   = $(this).find(_self._defaults.mediaTypes);
                $(media).hide().load(function(){
                    var media_w = $(media).width();
                    var media_h = $(media).height();

                    if(media_w > media_h){
                        var ratio_orig  =    media_w/media_h;
                        media_h         =   $win_w/ratio_orig;                    
                        media_w         =   $win_w;
                        $(media).css({
                            'height':media_h,
                            'margin-top':media_h/ -2,
                            'position':'absolute',
                            'top':'50%',
                            'width':$win_w
                        });
                    }                    
                }).fadeIn()

            });
        }
    };

    // Update the window width and height variables on window resize
    Plugin.prototype.resizeWindowDims = function () {
    	$(window).bind('load resize', function(){
            _self.resizeMedia();
			var $win_w = $(window).width();
			var $win_h = $(window).height();
    	}); 
    };


    // A really lightweight plugin wrapper around the constructor, 
    // preventing against multiple instantiations
    $.fn[pluginName] = function ( options ) {
        return this.each(function () {
            if (!$.data(this, 'plugin_' + pluginName)) {
                $.data(this, 'plugin_' + pluginName, 
                new Plugin( this, options ));
            }
        });
    }

})( jQuery, window, document );


