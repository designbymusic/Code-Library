<?php

//https://instagram.com/oauth/authorize/?display=touch&client_id=9b7162869c0240788b6126edff629ea2&redirect_uri=http://sandbox.localhost/instagram/callback.php&response_type=token
//access_token=989139.9b71628.ec1928f64d8c4e58aa9f5a7ccafb4ccd
// user id=989139
//https://api.instagram.com/v1/users/989139/media/recent/?access_token=989139.9b71628.ec1928f64d8c4e58aa9f5a7ccafb4ccd
DEFINE('INSTAGRAM_USER_ID', '989139');
DEFINE('INSTAGRAM_ACCESS_TOKEN', '989139.9b71628.ec1928f64d8c4e58aa9f5a7ccafb4ccd');

class Instagram {

    protected $username;
    protected $photocount;
    var $cache_dir;
    var $expire_time = 0;

    public function __construct($photocount) {

        $this->cache_dir = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'cache/twitter/tweets';

        //$this->_makeCachePath($this->cache_dir);

        $this->user_id = INSTAGRAM_USER_ID;
        $this->photocount = $photocount;
    }

    private function _curlDownload($Url) {

        // is cURL installed yet?
        if (!function_exists('curl_init')) {
            die('Sorry cURL is not installed!');
        }

        // OK cool - then let's create a new cURL resource handle
        $ch = curl_init();
        // Now set some options (most are optional)
        // Set URL to download
        curl_setopt($ch, CURLOPT_URL, $Url);
        // Set a referer
        curl_setopt($ch, CURLOPT_REFERER, "http://www.example.org/yay.htm");
        // User agent
        curl_setopt($ch, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
        // Include header in result? (0 = yes, 1 = no)
        curl_setopt($ch, CURLOPT_HEADER, 0);
        // Should cURL return or print out the data? (true = return, false = print)
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Timeout in seconds
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        // Download the given URL, and return output
        $output = curl_exec($ch);
        // Close the cURL resource, and free system resources
        curl_close($ch);
        return $output;
    }

    private function _makeCachePath($path) {
        //Test if path exist
        if (is_dir($path) || file_exists($path))
            return;
        //No, create it
        mkdir($path, 0777, true);
    }

}

function Instagram_getRecent() {
    
}

print_r($_GET);
?>
