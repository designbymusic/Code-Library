<?php

require_once 'phpflickr/phpFlickr.php';
#require_once 'image_cacher.php';

class Flickr {

    
    protected $photocount;
    private $user_id = '53572347@N02';
    private $api_key = '8e04f641eb2354aa4de3333bf1ece363';
    private $secret = '49f92ed2cd7a9a93';
    private $username = 'iamdashnet';
    private $tags = array(

    );
    private $extras = array(
        'date_taken',
        'date_upload',
        'description',
        'tags',
        'views',
        'url_q',
        'url_n',
        'url_o'
    );

    public function __construct($photocount) {
        $this->photocount = $photocount;
        $this->F = new phpFlickr($this->api_key, $this->secret);
        $this->lib = new MusicLib();
    }

    public function getRecent() {
        $opts = array(
            'tags'      => implode(',', $this->tags),
            'user_id'   => $this->user_id,
            'extras'    => implode(',', $this->extras),
            'per_page'  => $this->photocount
        );
        
        $response = $this->F->photos_search($opts);

        return $this->_normalizeFeed($response);
    }

    private function _normalizeFeed($response) {
        //$this->lib->d($response);
        $data = $response['photo'];
        
        $feed = array();
        $i = 0;
        foreach ($data as $d) {
            $feed[$i]['type'] = 'flickr';
            $feed[$i]['url'] = 'http://www.flickr.com/photos/'.$this->user_id.'/'.$d['id'];
            $feed[$i]['date'] = $d['dateupload'];
            $feed[$i]['title'] = $d['title'];
            $feed[$i]['image']['url'] = $d['url_o'];
            $feed[$i]['image']['w'] = $d['width_o'];
            $feed[$i]['image']['h'] = $d['height_o'];

            $feed[$i]['extras']['thumb'] = $d['url_n'];
            $feed[$i]['extras']['tags'] = explode(' ',$d['tags']);
            
            $feed[$i]['extras']['description'] = $d['description'];
            $feed[$i]['extras']['user']['username'] = $this->username;
            $feed[$i]['extras']['user']['url'] = 'http://flickr.com/photos/' . $this->username;

            $i++;
        }
        return $feed;
        //
        return $data;
    }

}