<?php

//https://instagram.com/oauth/authorize/?display=touch&client_id=9b7162869c0240788b6126edff629ea2&redirect_uri=http://sandbox.localhost/instagram/callback.php&response_type=token
//access_token=989139.9b71628.ec1928f64d8c4e58aa9f5a7ccafb4ccd
// user id=989139
//https://api.instagram.com/v1/users/'.INSTAGRAM_USER_ID.'/media/recent/?access_token='.INSTAGRAM_ACCESS_TOKEN
DEFINE('INSTAGRAM_USER_ID', '989139');
DEFINE('INSTAGRAM_ACCESS_TOKEN', '989139.9b71628.ec1928f64d8c4e58aa9f5a7ccafb4ccd');

class Instagram{


    private $api_domain     = 'https://api.instagram.com';
    private $api_version    = 'v1';
    private $user_id        = '989139';
    private $access_token   = '989139.9b71628.ec1928f64d8c4e58aa9f5a7ccafb4ccd';

    protected $photocount;

    public function __construct($photocount) {
        $this->photocount = $photocount;
        $this->lib = new MusicLib();
    }

    public function getRecent() {
        $params = array();
        $response = $this->lib->_curlDownload($this->_buildUrl($params));
        return $this->_normalizeFeed($response);
    }

    private function _normalizeFeed($response){
        $r = json_decode($response);
        $data = $r->data;

        $feed = array();
        $i=0;
        foreach($data as $d){
           
            $feed[$i]['type'] = 'instagram';
            $feed[$i]['url'] = $d->link;
            $feed[$i]['date'] = isset($d->created_time)?  $d->created_time:'';
            $feed[$i]['title'] = isset($d->caption)?  $d->caption->text:'';
            $feed[$i]['image']['url']  = $d->images->standard_resolution->url;
            $feed[$i]['image']['w']  = $d->images->standard_resolution->width;
            $feed[$i]['image']['h']  = $d->images->standard_resolution->height;

            $feed[$i]['extras']['tags'] = $d->tags;
            $feed[$i]['extras']['likes']['count'] = $d->likes->count;
            $feed[$i]['extras']['comments']['count'] = $d->comments->count;
            $feed[$i]['extras']['user']['username'] = isset($d->caption->from->username)?  $d->caption->from->username:'';
            $feed[$i]['extras']['user']['url'] = isset($d->caption->from->username)?  'http://instagram.com/'.$d->caption->from->username:'';

            $i++;
        }
        return $feed;
        //return $data;
    }


    private function _buildUrl($params){

        $url  = $this->api_domain;
        $url .= '/'.$this->api_version;
        $url .= '/users/'.$this->user_id.'/media/recent/?';

        foreach($params as $p=>$val){
            $url .= $p.'='.$val.'&';
        }
        $url .= 'access_token='.$this->access_token;
        $url .= '&count='.$this->photocount;

        return $url;
    }


}

?>
