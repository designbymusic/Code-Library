<?php
require_once 'SocialMediaFeeds.php';

function d($a) {
    echo '<pre style="font-family:\'Lucida Console\';font-size: 12px;padding: 20px;background: #fc0">' . print_r($a, true) . '</pre>';
}

;
?>
<style>
    h3{
        margin: 0;
    }
    ul{
        list-style: none;
    }
    li{
        background: url('img/spotify-logo.png') no-repeat right;
        border-bottom: 1px solid #999;
        float: left;
        clear: left;
        margin-bottom: 20px;
        padding-bottom: 20px;
        width: 50%;
    }
    li.instagram{
        background: url('img/instagram-logo.png') no-repeat right
    }
    li.flickr{
        background: url('img/flickr-logo.png') no-repeat right
    }
    li.twitter{
        background: url('img/twitter-logo.png') no-repeat right
    }
    li li{
        background: none;
        border: none;
        margin-bottom: 0;
        padding-bottom: 0;
        width: auto;
    }

    article{
        clear: left;
        display: block;
        float:left;

    }
    figure,.info{
        background: #eee;
        float: left;
        margin: 0 5px 5px 0;
        padding: 5px;
    }
    .info{
        background: #fff;
        font-size: 12px!important;
        padding: 0;
    }
    figcaption,span,date{
        clear: left;
        display: block;
        float: left;
        padding: 5px 0;
    }
</style>
<?php
$feeds = new SocialMediaFeeds(10);
$social_feeds = $feeds->getRecent();
#d($social_feeds);
?>
<ul>
<?php foreach ($social_feeds as $item): ?>
        <li class="<?php echo $item['type'];?>">
            <a href="<?php echo $item['url']; ?>">
                <figure>
                    <img src="<?php echo $item['image']['url']; ?>" height="60" width="60" />
                </figure>
                <div class="info">
                    <h3><?php echo $item['title']; ?></h3>
                    <date><?php echo $item['date'] !== 'now' ? date('d/m/Y H:i', $item['date']) : 'Now playing!'; ?></date>
                    <div class="extras">
                        <ul>
                                <?php foreach ($item['extras'] as $e => $val): ?>
                                <li>
                                    <?php echo $e; ?> :

                                    <?php if (is_array($val)): ?>
                                    <ul>
                                        <?php foreach ($val as $e2 => $val2): ?>
                                        <li>
                                        <?php echo $e2; ?> : <?php echo $val2;?>


                                        </li>
                                        <?php endforeach; ?>
                                     </ul>
                                    <?php else:?>
                                        <?php echo $val;?>
                                    <?php endif; ?>
                                </li>
                                <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </a>
        </li>
<?php endforeach; ?>
</ul>
