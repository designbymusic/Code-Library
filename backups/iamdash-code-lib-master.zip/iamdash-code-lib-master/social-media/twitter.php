<?php

//Access level	 Read-only
//Consumer key          fdWQrGLkCBTyaURRrkDn8w
//Consumer secret	bRaxWh7IafScEuo7JV5wCAzJF8ZbxgOiMTJ3EDvAAo
//Request token URL	https://api.twitter.com/oauth/request_token
//Authorize URL         https://api.twitter.com/oauth/authorize
//Access token URL	https://api.twitter.com/oauth/access_token
//Access token	594414034-dXGoKvB3t9tCuspUde9dgI28eK1cLDQZBM6LD542
//Access token secret	Z5jX8DymEIQIlD7m19AkjiOOSz8fKRAjabpe4eg
//Access level	Read-only

require_once('./twitteroauth/twitteroauth.php');

class Twitter {

    private $api_domain = 'https://api.twitter.com';
    private $api_key = '3zO6SRSbMx8ZFKIk6WW9qA';
    private $api_secret = '4ggezgCjwlxZadfsq0BiBucG56q7BMnGOcrZMLQU';
    private $oauth_token = '63937728-YflFiHIXEr39dkS6uTITqWHMG5kmBhG5PuWh1atZA';
    private $oauth_token_secret = 'ej6VrCh68SJUlbcgnEQAwN8x1YzSkjWSpsofyO94rc';
    private $multiple_user_list = 'ideas-by-music';
    private $user_id = '';
    private $username = '_iamdash';
    private $access_token = '';
    protected $photocount;

    public function __construct($itemcount) {
        $this->itemcount = $itemcount;
        $this->lib  = new MusicLib();
        $this->conn = new TwitterOAuth($this->api_key, $this->api_secret, $this->oauth_token, $this->oauth_token_secret);
    }



    public function getMultipleUserRecentTweets() {
        $content = $this->conn->get('lists/statuses', array(
            'slug' => $this->multiple_user_list,
            'owner_screen_name' => $this->username,
            'format' => 'json'
        ));


        return $this->_normalizeFeed(json_encode($content));
    }

    public function getRecent() {
        $content = $this->conn->get("statuses/user_timeline");

        return $content;
        $params = array();
        $response = $this->lib->_curlDownload($this->_buildUrl($params));
        return $this->_normalizeFeed($response);
    }

    private function _normalizeFeed($response) {
        $r = json_decode($response);

        $feed = array();
        $i = 0;
        foreach ($r as $d) {
            #$this->lib->d(strtotime($d->created_at));
            $feed[$i]['type'] = 'twitter';
            $feed[$i]['url'] = 'https://twitter.com/status/' . $d->user->screen_name . '/' . $d->id;
            $feed[$i]['date'] = strtotime($d->created_at);
            $feed[$i]['title'] = '<a href="http://www.twitter.com/' . $d->user->screen_name . '">' . $d->user->screen_name . '</a> tweeted';
            $feed[$i]['image']['url']  = $d->user->profile_image_url;
            $feed[$i]['image']['w']  = 300;
            $feed[$i]['image']['h']  = 300;
            $feed[$i]['extras']['tweet'] = $this->_parseTweet($d);
            $feed[$i]['extras']['user']['username'] = $d->user->screen_name;
            $feed[$i]['extras']['user']['url'] = 'http://www.twitter.com/' . $d->user->screen_name;

            $i++;
        }
        return $feed;
        //return $data;
    }

    private function _buildUrl($params) {

        $url = $this->api_domain;
        $url .= '/' . $this->api_version;
        $url .= '/users/' . $this->user_id . '/media/recent/?';

        foreach ($params as $p => $val) {
            $url .= $p . '=' . $val . '&';
        }
        $url .= 'access_token=' . $this->access_token;
        $url .= '&count=' . $this->photocount;

        return $url;
    }

    private function _parseTweet($tweet) {
        $t['raw'] = $tweet->text;
        // link URLs
        $t['parsed'] = " " . preg_replace("/(([[:alnum:]]+:\/\/)|www\.)([^[:space:]]*)([[:alnum:]#?\/&=])/i", "<a href=\"\\1\\3\\4\" target=\"_blank\">\\1\\3\\4</a>", $tweet->text);

        // link mailtos
        $t['parsed'] = preg_replace("/(([a-z0-9_]|\\-|\\.)+@([^[:space:]]*)" .
                "([[:alnum:]-]))/i", "<a href=\"mailto:\\1\">\\1</a>", $t['parsed']);

        //link twitter users
        $t['parsed'] = preg_replace("/ +@([a-z0-9_]*) ?/i", " <a href=\"http://twitter.com/\\1\" target=\"_blank\">@\\1</a> ", $t['parsed']);

        //link twitter arguments
        $t['parsed'] = preg_replace("/ +#([a-z0-9_]*) ?/i", " <a href=\"http://twitter.com/search?q=%23\\1\" target=\"_blank\">#\\1</a> ", $t['parsed']);

        // truncates long urls that can cause display problems (optional)
        $t['parsed'] = preg_replace("/>(([[:alnum:]]+:\/\/)|www\.)([^[:space:]]" .
                "{30,40})([^[:space:]]*)([^[:space:]]{10,20})([[:alnum:]#?\/&=])" .
                "</", ">\\3...\\5\\6<", $t['parsed']);
        $t['parsed'] = preg_replace('/%u([a-fA-F0-9]{4})/', '&#x\\1;', $t['parsed']);
        return $t;
    }

}

?>
