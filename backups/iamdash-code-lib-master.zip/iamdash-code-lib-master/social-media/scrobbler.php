<?php
//API Key: 3cc67f2c699cc0c0aa73d043b1b30d00
//Secret: is 8b4233f1743c5490eef6a62b796bc426

DEFINE('LASTFM_API_KEY', '3cc67f2c699cc0c0aa73d043b1b30d00');
DEFINE('LASTFM_SECRET', '8b4233f1743c5490eef6a62b796bc426');
class Scrobbler{

    protected $api_domain   =   'http://ws.audioscrobbler.com';
    protected $api_version  =   '2.0';
    protected $user         =   'ideasbymusic';
    protected $api_key      =   '3cc67f2c699cc0c0aa73d043b1b30d00';
    protected $secret       =   '8b4233f1743c5490eef6a62b796bc426';
    protected $trackcount;


    var $cache_dir;
    var $expire_time = 0;

    public function __construct($trackcount) {


        $this->trackcount   = $trackcount-1;
        $this->lib = new MusicLib();
    }

    public function getRecent() {
        $params = array(
            'user'=>$this->user,
            'method'=>'user.getrecenttracks',
            'format'=>'json'
        );
        $response = $this->lib->_curlDownload($this->_buildUrl($params));
        return $this->_normalizeFeed($response);
    }

    private function _normalizeFeed($response){
        $r = json_decode($response);

        $data = $r->recenttracks->track;

        $feed = array();
        $i=0;
        foreach($data as $d){

            $date       = isset($d->date) ? get_object_vars($d->date):null;
            $artist     = get_object_vars($d->artist);
            $album      = get_object_vars($d->album);
            $image      = get_object_vars($d->image[3]);

            $feed[$i]['type']   = 'jukebox';
            $feed[$i]['url']    = $d->url;
            $feed[$i]['date']   = $date == null ? 'now':$date['uts'];
            $feed[$i]['title']  = $d->name;
            $feed[$i]['image']['url']   = $image['#text'];
            $feed[$i]['image']['w']     = 300;
            $feed[$i]['image']['h']     = 300;

            $feed[$i]['extras']['artist']   = $artist['#text'];
            $feed[$i]['extras']['album']    = $album['#text'];
            $feed[$i]['extras']['user']['username'] = $this->user;
            $feed[$i]['extras']['user']['url'] = 'http://lastfm.com/user/'.$this->user;

            $i++;
        }
        return $feed;
        return $data;
    }

    private function _buildUrl($params){
        $url  = $this->api_domain;
        $url .= '/'.$this->api_version.'/?';
        foreach($params as $p=>$val){
            $url .= $p.'='.$val.'&';
        }
        $url .= 'api_key='.$this->api_key;
        $url .= '&limit='.$this->trackcount;

        return $url;
    }
}
?>
