<?php

require_once ('lib.php');
require_once('instagram.php');
require_once('scrobbler.php');
require_once('flickr.php');
require_once('twitter.php');

class SocialMediaFeeds {

    private $recentFeeds;

    public function __construct($itemcount) {
        $this->lib = new MusicLib();
        $this->Instagram    = new Instagram($itemcount);
        $this->Scrobbler    = new Scrobbler($itemcount);
        $this->Flickr       = new Flickr($itemcount);
        $this->Twitter      = new Twitter($itemcount);
    }

    public function getRecent() {
        $this->recentFeeds = array();
        $this->recentFeeds['Instagram'] = $this->Instagram->getRecent();
        $this->recentFeeds['Scrobbler'] = $this->Scrobbler->getRecent();
        $this->recentFeeds['Flickr'] = $this->Flickr->getRecent();
        $this->recentFeeds['TwitterTweets'] = $this->Twitter->getMultipleUserRecentTweets();

        $feeds = array_merge(
                $this->recentFeeds['Instagram'],
                $this->recentFeeds['Scrobbler'],
                $this->recentFeeds['Flickr'],
                $this->recentFeeds['TwitterTweets']
                );
        return $this->_sortByValue($feeds,'date');
    }

    private function _sortFeeds() {

    }

    private function _sortByValue(&$array, $key) {
        $sorter = array();
        $ret = array();
        reset($array);
        foreach ($array as $ii => $va) {
            $sorter[$ii] = $va[$key];
        }
        asort($sorter);
        foreach ($sorter as $ii => $va) {
            $ret[$ii] = $array[$ii];
        }
        $array = $ret;
        return array_reverse(array_merge($array, array()));
    }

}
?>
