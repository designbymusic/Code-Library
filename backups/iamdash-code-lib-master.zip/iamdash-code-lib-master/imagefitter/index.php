<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <style>
            *{
                margin: 0;
                padding: 0;
            }
            #media-wrap{
                background: #eee;
                height: 100%;
                left: 0;
                position: fixed;
                top: 0;
                width: 100%;
            }
        </style>
    </head>
    <body>
        <div id="media-wrap">
            <?php if($_GET['type']=='image'):?>
            <img src="images/<?php echo $_GET['o'];?>.jpg" />
            <?php endif;?>
            <?php if($_GET['type']=='video'):?>
                <video id="video" muted="" loop="" autoplay="">
                    <source src="video/remy-and-ellis2.mp4">
                    <source src="video/remy-and-ellis2.webm">
                  </video>
            <?php endif;?>            
        </div>
        <script src="js/jquery.js"></script>
        <script>
            $(window).load(function(){
                $('#media-wrap').mediaFittr({
                    
                });
            });
            $(window).resize(function(){
                $('#media-wrap').mediaFittr({
                    
                });
            });             
            (function($){
 
                $.fn.extend({ 
         
                    //pass the options variable to the function
                    mediaFittr: function(options) {
                        
                        //Set the default values, use comma to separate the settings, example:
                        var defaults = {
                            mediaTypes: 'img, video'
                        }
                 
                        var options =  $.extend(defaults, options);
                        var o = options;

                        var $wrapper        =   $(this);
                        var $win_w          =   $wrapper.width();
                        var $win_h          =   $wrapper.height();
                        var $the_media      =   $wrapper.find(o.mediaTypes);
                        var $media_w        =   $($the_media).width();
                        var $media_h        =   $($the_media).height();                        
                        var $orientation    =   'portrait';
                        var $ratio_orig     =    $media_h/$media_w;
                        var $media_offset_top   = 0;
                        var $media_offset_left  = 0;
                        var $media_margin_left  =   $win_w/2;
                        
                        return this.each(function() {
                            _calculateMediaOrientation();
                        });
                       
                        function _positionMedia(){
                            _calculateMediaOrientation();
                        }
                        
                        function _calculateMediaOrientation(){
                            if($media_w > $media_h){
                                $orientation = 'landscape';
                            }else if($media_w == $media_h){
                                $orientation = 'square';
                            }else{
                                
                            }
                            _calculateMediaDimensions($orientation);
                        }
                        function _calculateMediaDimensions(orientation){                          
                            switch($orientation){
                                case 'landscape':
                                    $ratio_orig =    $media_w/$media_h;
                                    $media_w = $wrapper;
                                    $media_h = $win_w/$ratio_orig;
                                break;
                                case 'portrait':
                                    $media_h = $win_h;
                                    $media_w = $win_h/$ratio_orig;
                                break;
                            }
                            _calculateMediaPosition(orientation);
                        }
                        function _calculateMediaPosition(orientation){
                            switch(orientation){
                                case 'landscape':
                                    $media_offset_top   = ($win_h - $media_h)/2;
                                    $media_offset_left  = 0;
                                break;
                                case 'portrait':
                                    $media_offset_top   =   0;
                                    $media_offset_left  =   ($win_w - $media_w)/2;
                                break;
                                
                            }
                            console.log($media_offset_left,$media_offset_top);
                            $($the_media).css({
                                'height':       $media_h,
                                'left':         $media_offset_left,
                                'position':     'absolute',
                                'top':          $media_offset_top,
                                'width':        $media_w
                            });
                        }
                    }
                });
     
            })(jQuery);            
        </script>
    </body>
</html>
