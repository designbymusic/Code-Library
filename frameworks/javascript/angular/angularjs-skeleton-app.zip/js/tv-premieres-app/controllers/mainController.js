app.controller("mainController", function($scope, $http){

    $scope.init = function() {

    };

});

